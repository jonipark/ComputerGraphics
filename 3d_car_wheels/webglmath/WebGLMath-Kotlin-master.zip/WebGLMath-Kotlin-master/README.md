# WebGLMath-Kotlin
Vector-matrix and uniform reflection library for WebGL with Kotlin2JS
